/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

/*Crie um programa que exiba a tabuada do número 5 até o número 10.*/

int main()
{
    int j = 5;
    cout << "A tabuada de 5 é: ";
    
    for (int i = 1; i < 11; i++) {
        
    cout << "\n" << j << "x" << i << "=" << (i*j);
    }
    return 0;
}