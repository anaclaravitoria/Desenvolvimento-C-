/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

/* Escreva um programa que solicite ao usuário para digitar três números
inteiros e exiba se o primeiro número é menor que o segundo número e
maior que o terceiro número.*/

int main()
{
    int num1;
    int num2;
    int num3;
    
    cout << "Dite seu 1ªnúmero ";
    cin >> num1;
    cout << "Digite seu 2ªnúmero ";
    cin >> num2;
    cout <<  "Digite seu 3ªnúmero ";
    cin >> num3;
    
    if (num1 < num2 && num1 > num3) {
     cout << "o primeiro número é menor que o segundo número e maior que o terceiro número.";
     } else {
         cout << "Nenhum dos números é menor que 2ª e maior que 3ª";
     }
}
