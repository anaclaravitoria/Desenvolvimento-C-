/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*Crie um programa que solicite ao usuário para inserir uma sequência de
números inteiros e, em seguida, exiba a soma desses números.*/
int main()
{
    int num = 1;
    int soma = 0;
    int number;
    
    cout << "Insira uma sequência de números inteiros.";
    cout << "\nDigite 0 para parar.\n";
    while(num != 0){
    cin >> num;
    soma += num;
    }
    
    cout << "O resultado da soma é: " << soma;
    return 0;
}
    