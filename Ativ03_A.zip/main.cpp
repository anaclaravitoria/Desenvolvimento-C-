/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/* Escreva um programa que solicite ao usuário para digitar dois números
inteiros e exiba se o primeiro número é maior que o segundo número.Escreva um programa que solicite ao usuário para digitar dois números
inteiros e exiba se o primeiro número é maior que o segundo número.*/


int main(){
int num1;
int num2;

cout << "Insira seu 1° número ";
cin >> num1;
cout << "Inisra o seu 2° número ";
cin >> num2;

if (num1 > num2) {
    cout << "O maior número é: " << num1;
} else {
    cout << num2;
 }
 
 return 0;
}


