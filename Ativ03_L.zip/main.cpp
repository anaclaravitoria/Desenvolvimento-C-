/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/* Escreva um programa que solicite ao usuário para digitar dois números
inteiros e exiba se a diferença entre eles é menor ou igual a 10.*/

int main()
{
    int num1;
    int num2;
    int diferença;
    
    cout << "Digite um número inteiro: ";
    cin >> num1;
    
    cout << "Digite outro número inteiro: ";
    cin >> num2;
    
    diferença = num1 - num2;
    
    if (diferença < 0){
        diferença *= -1;
        cout << "A diferença é de " << diferença;
     } else {
        cout << "A diferença é de " << diferença;
      }
        
     return 0;
    }