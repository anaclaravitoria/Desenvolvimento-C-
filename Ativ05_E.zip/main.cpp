/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*Crie um programa que solicite ao usuário para inserir um número inteiro e,
em seguida, exiba se esse número é primo ou não.*/
    bool isPrime (int num) {
        if ( num <= 1) {
            return false;
        }
        
    
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            return false;
        }
    }
    return true;
}
int main(){
    int num;
    
    cout << "Digite um número inteiro: ";
    cin >> num;
    
    if (isPrime(num)) {
        cout << num << " é um número primo.\n";
    } else {
        cout << num << " não é um número primo.\n";
    }
    
    return 0;
}