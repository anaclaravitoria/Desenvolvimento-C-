/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/* Escreva um programa que solicite ao usuário para digitar dois números reais
e exiba se o primeiro número é maior ou igual ao segundo número.*/



int main() 
{int num1;
int num2;

cout << "Inisira o seu 1ª número ";
cin >> num1;
cout << "Insira o seu 2ª número ";
cin >> num2;

if (num1 > num2 || num1 == num2) {
    cout << "Seus números são iguais ou maior que o segundo";
} else {
    cout << "Seus números não são iguais ou talvez o 2ª é maior que o 1ª";
}
}