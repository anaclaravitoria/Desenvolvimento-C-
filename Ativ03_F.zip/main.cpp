/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream>
#include <locale.h>
using namespace std;
/*Escreva um programa que solicite ao usuário para digitar um número inteiro
e exiba se ele é par.
OBS.: Um número é par se ele for divisível por 2, ou seja, se o resto da divisão por 2 for igual a zero.*/
int main() {
    int num;
    
    cout << "Digite um número: ";
    cin >> num;
    
    if (num % 2 == 0) {  // Verifica se o número é par
        cout << "O número " << num << " é par." << endl;
    } else {
        cout << "O número " << num << " não é par." << endl;
    }

    return 0;
}
