/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*Escreva um programa que solicite ao usuário para digitar dois números
inteiros e exiba se eles são iguais.*/

int main()
{ 
    int num1;
    int num2;
    
    cout << "Insira o seu 1ª número ";
    cin >> num1;
    cout << "Insira o s eu 2ªnúmero ";
    cin >> num2;
    
    if (num1 == num2) {
        cout << "Os números digitados são iguais: \n" << "1ª: " << num1  << "\n" << "2ª: " << num2;
   } else {
        cout << "Os números são diferentes,por isso não é possível imprimí-los" ;
 }
}