/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <iostream>
using namespace std;
/*Desenvolva um programa que solicite ao usuário para inserir uma sequência
de números inteiros e, em seguida, exiba o maior número inserido
*/
int main(){
    int num[10];
    cout << "Insira uma sequência de números.";
    
    for (int i =0; i < 10; i++) {
    cin >> num[i];
    }
    
    int num1 = num[0];
    for (int i = 0; i < 10;i++) {
        if (num[i] > num1){
            num1 = num[i];
        }
    }
    
    cout << "O maior número é "<< num1;
    return 0;
}