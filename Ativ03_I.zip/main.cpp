/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/* Escreva um programa que solicite ao usuário para digitar um número inteiro
e exiba se ele é positivo.*/
int main()
{
    int num;
    
    cout << "Digite um número ";
    cin >> num;
    
    if (num > 0) {
        cout << "O número " << num << " é positivo";
    } else {
        cout << "O número " << num << " não é positivo";
    }
}