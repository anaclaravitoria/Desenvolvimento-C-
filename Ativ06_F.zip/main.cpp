/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*Crie um programa que solicite ao usuário para inserir um número inteiro
positivo e, em seguida, exiba todos os números pares entre 0 e o número
inserido.*/
int main(){
    int num;
    
    cout << "Digite um número positivo";
    cin >> num;
    
    // verificando se o número e positivo
    
    if (num < 0) {
        cout << "Por favor,tente novamente com um número positivo";
        return 1; // encerra o programa
    }
    
    int i = 0;
    
    cout << "Os números pares entre " << num << " são: \n";
    while ( i <= num){
        if ( i % 2 == 0) {
            cout <<  i  << "  ";
        }
        i++;
    }
    return 0;
}