/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/* Escreva um programa que solicite ao usuário para digitar o seu endereço
completo, incluindo o número da casa, rua, bairro, cidade e estado.
Armazene cada informação em uma variável string e, em seguida, exiba
todas as informações juntas em uma única linha. */

int main()
{
    string rua;
    string bairro;
    string cidade;
    string estado;
    
    cout << "Digite o nome da sua rua e o número: ";
    getline (cin , rua);
    cout << "\n Digite o nome do seu bairro";
    getline (cin , bairro);
    cout << "\n Digite o nome da sua cidade";
    getline (cin , cidade);
    cout << "\n Digite o nome do seu estado";
    getline (cin , estado);
    
    cout << "Sua rua é: " << rua << "\n Seu bairro é : " << bairro << "\n Sua cidade é: " << cidade << "\n Seu estado é: " << estado;
    
   return 0;
}