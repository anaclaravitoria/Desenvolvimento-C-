/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <stdio.h>
#include <locale.h>
using namespace std;
/*Escreva um programa que solicite ao usuário para digitar um número inteiro
e exiba se ele é ímpar.
OBS.: Um número é ímpar se ele não for divisível por 2, ou seja, se o resto da divisão por 2 for
diferente de zero.*/
int main() {
    int num;
    
    cout << "Digite um número: ";
    cin >> num;
    
    if (num % 2 == 0) {  // Verifica se o número é impar
        cout << "O número " << num << " é par." << endl;
    } else {
        cout << "O número " << num << " é ímpar." << endl;
    }

    return 0;
}
