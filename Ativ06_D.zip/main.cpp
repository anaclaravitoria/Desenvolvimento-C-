/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*Desenvolva um programa que solicite ao usuário para inserir uma senha e,
em seguida, permita que o usuário tente inserir a senha até três vezes. Caso o
usuário acerte a senha, exiba uma mensagem de sucesso. Caso contrário,
exiba uma mensagem informando que a senha está incorreta.*/
int main(){
    
    string senha = "ana";
    string tentativa = "a";
    int i = 0;
    
    while (tentativa != senha){
        cout << "Seja bem vindo!\nDigite sua senha:";
        cin >> tentativa;
        if (i == 2) {
        break;
        }
        i++;
    }
    
    if (tentativa == senha){
        cout << "Senha correta!";
        
    } else {
        cout << "Tente novamente mais tarde!";
    }
    
    return 0;
}