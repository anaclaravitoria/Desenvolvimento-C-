/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/* Escreva um programa que solicite ao usuário para digitar um ano. Verifique
se um ano é bissexto.
OBS.: Um ano é bissexto se for divisível por 4,
mas não por 100, exceto se for divisível por 400.*/

int main()
{
    int ano;
    
    cout << "Digi um ano para descobrir se ele é bissexto ou não";
    cin >> ano;
    
    if (ano % 4 == 0) {
        cout << "Esse ano " << ano << " è bissexto";
    } else {
        cout << "Esse ano " << ano << " não é bissexto";
    }
}