/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*Crie um programa que solicite ao usuário para inserir números inteiros até
que um número negativo seja inserido. Em seguida, exiba a soma dos
números inseridos (excluindo o número negativo).*/
int main(){
    int num = 1;
    int soma = 0;
    
    cout << "Digite uma sequência de números\n";
    
    while (num > 0) {
        cin >> num;
        soma += num;
    }
    
    cout << "\nA soma dos números são: " << soma;
    
    return 0;
}