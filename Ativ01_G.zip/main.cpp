/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/* Escreva um programa que solicite ao usuário para digitar o seu nome e a sua
idade, e armazene-os em variáveis, respectivamente. Em seguida, exiba essas
informações na tela.*/

int main()
{
 int idade;
 string nome;
 
 cout << "Insira a sua idade ";
 cin >> idade;
 cout << "Insira o seu nome ";
 cin >> nome;
 
 cout << "Seu nome é " << nome << "\n Sua idade é " << idade;
 
 return 0 ;
 
    
}