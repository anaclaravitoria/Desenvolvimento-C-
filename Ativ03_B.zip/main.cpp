/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/* Escreva um programa que solicite ao usuário para digitar dois números
inteiros e exiba se o primeiro número é menor que o segundo número. */

int main(){
    int num1;
    int num2;
    
    cout << "Digite seu 1ªnúmero ";
    cin >> num1;
    cout << "Diite seu 2ª número ";
    cin >> num2;
    
    if (num1 > num2) {
        cout << num2;
} else {
        cout << num1;
 }
}
