/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*Crie um programa que solicite ao usuário para inserir uma palavra e, em
seguida, exiba cada letra da palavra em uma linha separada.*/
int main()
{
    string palavra;
    cout << "Digite uma palavra: ";
    cin >> palavra;
    
    for (int i = 0; i < palavra.length(); i++){
        cout << "\n" << palavra[i] ;
    }
}