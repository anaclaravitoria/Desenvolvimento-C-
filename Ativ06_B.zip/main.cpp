/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*Desenvolva um programa que solicite ao usuário para inserir um número
inteiro e, em seguida, exiba a tabuada desse número até o número 10.*/
int main()
{
    int num, i =1;
    
    cout << "Insira um número";
    cin >> num;
    
    cout << "Tabuada do "<< num << "\n";
    
    while ( i <= 10) {
        cout << num << "x" << i << "=" << num * i << "\n";
        i++;
    }
    return 0;
}