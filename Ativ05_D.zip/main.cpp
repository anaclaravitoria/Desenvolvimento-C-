/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

/*Desenvolva um programa que solicite ao usuário para inserir um número
inteiro positivo e, em seguida, exiba a soma de todos os números entre 1 e o
número inserido.*/
int main()
{
    int num;
    cout << "Dgite um número positivo: ";
    cin >> num;
    int soma;
    
    cout << "A soma de todas esses números são: ";
    
    for (int i = 1; i <= num; i++) {
        soma += i;
    }
    cout << soma;
    return 0;
}