/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
/*Faça um programa que apresente um menu com as opções de meses do ano
(janeiro a dezembro) e solicite ao usuário que escolha um mês. Em seguida,
exiba uma mensagem informando a quantidade de dias do mês escolhido.*/

int main(){
    
    int meses;
    
    cout << "Escolha um dos meses do ano,por número ";
    cin >> meses;
    
    if (meses == 1) {
        cout << "Janeiro contém 31 dias";
    } else if (meses == 2) {
       cout << "fevereiro em ano bissexto contém 29 dias,\n fora disso 28 anos";
    } else if (meses == 3) {
       cout << "Março contém 30 dias";
    } else if (meses == 4) {
       cout << "Abril contém 31 dias";
    } else if (meses == 5) {
       cout << "Maio contém 30 dias"; 
    } else if (meses == 6) {
       cout << "Junho contém 31 dias";
    }else if (meses == 7) {
       cout << "Julho contém 30 dias";
    } else if (meses == 8) {
       cout << "Agosto contém 31 dias";
    } else if (meses == 9) {
       cout << "Setmbro contém 30 dias";
    } else if (meses == 10) {
       cout << "Outubro contém 31 dias";
    } else if (meses == 11) {
       cout << "Novembro contém 30dias"; 
    } else if (meses == 12) {
       cout << "dezembro contém 31 dias";
    } else {
       cout << "Não existe mês com esse número";
    }
}